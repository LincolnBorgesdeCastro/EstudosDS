# Usando o addd-in GREA

# Que tal uma interface gráfica para importar seus arquivos?

devtools::install_github("Stan125/GREA", force = TRUE)

# Clique em: Tools --> Addins --> Gotta Read Em All