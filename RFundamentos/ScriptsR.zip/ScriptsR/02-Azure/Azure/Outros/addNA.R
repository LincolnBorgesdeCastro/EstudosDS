# Este código contém comandos para filtrar e plotar os dados de aluguel de bikes, dados que estão em nosso dataset
# Este código foi criado para executar tanto no Azure, quanto no RStudio.
# Para executar no Azure, altere o valor da variável Azure para TRUE. Se o valor for FALSE, o código será executado no RStudio

# Variável que controla a execução do script
Azure <- FALSE

# Execução de acordo com o valor da variável Azure
if(Azure){
  source("src/Tools.R")
  Bikes <- maml.mapInputPort(1)
  Bikes$dteday <- set.asPOSIXct(Bikes)
}else{
  source("Tools.R")
  Bikes <- read.csv("bikes.csv", sep = ",", header = T, stringsAsFactors = F )
  Bikes$dteday <- char.toPOSIXct(Bikes)
}

# Adicionando NA's - RStudio
Bikes$cnt <- ifelse(Bikes$cnt < 20, NA, Bikes$cnt)
is.na((Bikes$cnt))

# Adicionando NA's - Azure
# Map 1-based optional input ports to variables
dataset1 <- maml.mapInputPort(1) # class: data.frame

dataset1$cnt <- ifelse(dataset1$cnt < 20, NA, dataset1$cnt)

# Select data.frame to be sent to the output Dataset port
maml.mapOutputPort("dataset1");


# Resultado
if(Azure) maml.mapOutputPort("Bikes")